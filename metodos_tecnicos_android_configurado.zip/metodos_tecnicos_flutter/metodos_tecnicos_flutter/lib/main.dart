import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const MetodosTecnicosApp());
}

bool get cloudConfigured => supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

class MetodosTecnicosApp extends StatelessWidget {
  const MetodosTecnicosApp({super.key});

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF0B1220);
    const panel = Color(0xFF142238);
    const blue = Color(0xFF3985F6);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Métodos Técnicos',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: blue, surface: panel, secondary: Color(0xFF7DB3FF),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: bg, elevation: 0, centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
        cardTheme: CardThemeData(
          color: panel, margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        useMaterial3: true,
      ),
      home: cloudConfigured ? const AuthGate() : const SetupScreen(),
    );
  }
}

class SetupScreen extends StatelessWidget {
  const SetupScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.cloud_outlined, size: 64, color: Color(0xFF3985F6)),
        const SizedBox(height: 18),
        const Text('Métodos Técnicos', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        const Text('O visual inicial está pronto. Para ativar login e sincronização, configure as chaves do seu projeto Supabase seguindo o README incluído.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
      ]),
    )),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: Supabase.instance.client.auth.onAuthStateChange,
    builder: (context, snapshot) {
      final session = Supabase.instance.client.auth.currentSession;
      return session == null ? const LoginScreen() : const HomeScreen();
    },
  );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool creating = false, busy = false;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      final auth = Supabase.instance.client.auth;
      if (creating) {
        await auth.signUp(email: email.text.trim(), password: password.text);
      } else {
        await auth.signInWithPassword(email: email.text.trim(), password: password.text);
      }
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (_) {
      setState(() => error = 'Não foi possível conectar. Confira sua internet e as configurações.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Icon(Icons.phone_android, size: 58, color: Color(0xFF3985F6)),
        const SizedBox(height: 12),
        const Text('Métodos Técnicos', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Sua biblioteca técnica na nuvem', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 30),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-mail', prefixIcon: Icon(Icons.email_outlined))),
        const SizedBox(height: 12),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Senha', prefixIcon: Icon(Icons.lock_outline))),
        if (error != null) ...[const SizedBox(height: 12), Text(error!, style: const TextStyle(color: Colors.redAccent))],
        const SizedBox(height: 18),
        FilledButton(onPressed: busy ? null : submit, child: Padding(padding: const EdgeInsets.all(12), child: Text(busy ? 'Aguarde...' : creating ? 'Criar conta' : 'Entrar'))),
        TextButton(onPressed: () => setState(() { creating = !creating; error = null; }), child: Text(creating ? 'Já tenho uma conta — entrar' : 'Criar minha conta')),
      ]),
    ))),
  );
}

const categories = ['Samsung', 'Motorola', 'Xiaomi', 'iPhone', 'Realme', 'Outros'];

class TechMethod {
  final String id, title, brand, model, description;
  final bool favorite;
  TechMethod.fromMap(Map<String, dynamic> m)
      : id = m['id'].toString(), title = m['title'] ?? '',
        brand = m['brand'] ?? 'Outros', model = m['model'] ?? '',
        description = m['description'] ?? '', favorite = m['favorite'] == true;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  final search = TextEditingController();
  String selected = 'Todos';
  bool favoritesOnly = false;
  Future<List<TechMethod>> load() async {
    var query = Supabase.instance.client.from('methods').select();
    if (selected != 'Todos') query = query.eq('brand', selected);
    if (favoritesOnly) query = query.eq('favorite', true);
    final term = search.text.trim();
    if (term.isNotEmpty) {
      query = query.or('title.ilike.%$term%,model.ilike.%$term%,description.ilike.%$term%');
    }
    final rows = await query.order('created_at', ascending: false);
    return (rows as List).map((e) => TechMethod.fromMap(e)).toList();
  }

  Future<void> openEditor([TechMethod? method]) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => MethodEditor(method: method)));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Métodos Técnicos', style: TextStyle(fontWeight: FontWeight.bold)),
        Text('Sua biblioteca profissional', style: TextStyle(fontSize: 12, color: Colors.white54)),
      ]),
      actions: [
        IconButton(tooltip: 'Favoritos', onPressed: () => setState(() => favoritesOnly = !favoritesOnly),
          icon: Icon(favoritesOnly ? Icons.star : Icons.star_border, color: favoritesOnly ? Colors.amber : null)),
        IconButton(tooltip: 'Sair', onPressed: () => Supabase.instance.client.auth.signOut(), icon: const Icon(Icons.logout)),
      ],
    ),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => openEditor(), icon: const Icon(Icons.add), label: const Text('Novo método')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 12), child: TextField(
        controller: search, onChanged: (_) => setState(() {}),
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Pesquisar método, modelo...'),
      )),
      SizedBox(height: 44, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
        _chip('Todos'),
        ...categories.map(_chip),
      ])),
      const SizedBox(height: 12),
      Expanded(child: FutureBuilder<List<TechMethod>>(
        future: load(), builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snap.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Erro ao carregar métodos. Confira a tabela e as permissões no Supabase.\n${snap.error}', textAlign: TextAlign.center)));
          final items = snap.data ?? [];
          if (items.isEmpty) return const _EmptyState();
          return ListView.separated(padding: const EdgeInsets.fromLTRB(16, 0, 16, 100), itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final m = items[i];
              return Card(child: ListTile(
                contentPadding: const EdgeInsets.all(14),
                leading: CircleAvatar(backgroundColor: const Color(0xFF203D63), child: Icon(Icons.phone_android, color: Colors.blue[200])),
                title: Text(m.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text('${m.brand} • ${m.model}\n${m.description}', maxLines: 2, overflow: TextOverflow.ellipsis)),
                isThreeLine: true,
                trailing: Icon(m.favorite ? Icons.star : Icons.chevron_right, color: m.favorite ? Colors.amber : null),
                onTap: () => openEditor(m),
              ));
            });
        },
      )),
    ]),
  );

  Widget _chip(String label) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(
    label: Text(label), selected: selected == label,
    onSelected: (_) => setState(() => selected = label),
  ));
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();
  @override
  Widget build(BuildContext context) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(Icons.folder_open, size: 58, color: Colors.blue[200]),
    const SizedBox(height: 12),
    const Text('Nenhum método cadastrado', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
    const SizedBox(height: 5),
    const Text('Toque em “Novo método” para começar.', style: TextStyle(color: Colors.white60)),
  ]));
}

class MethodEditor extends StatefulWidget {
  final TechMethod? method;
  const MethodEditor({super.key, this.method});
  @override
  State<MethodEditor> createState() => _MethodEditorState();
}
class _MethodEditorState extends State<MethodEditor> {
  final title = TextEditingController(), model = TextEditingController(), description = TextEditingController(), android = TextEditingController();
  String brand = categories.first;
  bool favorite = false, busy = false;
  String? error;

  @override
  void initState() {
    super.initState();
    final m = widget.method;
    if (m != null) {
      title.text = m.title; model.text = m.model; description.text = m.description;
      brand = m.brand; favorite = m.favorite;
    }
  }

  Future<void> save() async {
    if (title.text.trim().isEmpty) { setState(() => error = 'Informe o título do método.'); return; }
    setState(() { busy = true; error = null; });
    try {
      final data = {
        'title': title.text.trim(), 'brand': brand, 'model': model.text.trim(),
        'description': description.text.trim(), 'android_version': android.text.trim(),
        'favorite': favorite,
      };
      final table = Supabase.instance.client.from('methods');
      if (widget.method == null) {
        await table.insert(data);
      } else {
        await table.update(data).eq('id', widget.method!.id);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => error = 'Não foi possível salvar. Confira as permissões do banco.\n$e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> remove() async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Excluir método?'), content: const Text('Esta ação não pode ser desfeita.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Excluir'))],
    ));
    if (ok == true) {
      await Supabase.instance.client.from('methods').delete().eq('id', widget.method!.id);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.method == null ? 'Novo método' : 'Editar método'),
      actions: [if (widget.method != null) IconButton(onPressed: remove, icon: const Icon(Icons.delete_outline))]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      TextField(controller: title, decoration: const InputDecoration(labelText: 'Nome do método *')),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: brand, decoration: const InputDecoration(labelText: 'Marca'), items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (v) => setState(() => brand = v ?? brand)),
      const SizedBox(height: 12),
      TextField(controller: model, decoration: const InputDecoration(labelText: 'Modelo do aparelho')),
      const SizedBox(height: 12),
      TextField(controller: android, decoration: const InputDecoration(labelText: 'Versão Android / iOS')),
      const SizedBox(height: 12),
      TextField(controller: description, minLines: 5, maxLines: 12, decoration: const InputDecoration(labelText: 'Procedimento / observações', alignLabelWithHint: true)),
      SwitchListTile(contentPadding: EdgeInsets.zero, value: favorite, onChanged: (v) => setState(() => favorite = v), title: const Text('Adicionar aos favoritos')),
      if (error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: busy ? null : save, icon: const Icon(Icons.cloud_upload_outlined), label: Padding(padding: const EdgeInsets.all(12), child: Text(busy ? 'Salvando...' : 'Salvar na nuvem'))),
    ]),
  );
}
