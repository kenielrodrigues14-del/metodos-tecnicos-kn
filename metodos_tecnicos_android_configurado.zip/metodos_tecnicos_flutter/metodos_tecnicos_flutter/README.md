# Métodos Técnicos — Android

Projeto inicial em Flutter com visual dark e integração com Supabase.

## Configuração do seu projeto Supabase

A URL informada para este projeto é:

`https://qteoohevgetmaphuayjx.supabase.co`

Use a chave **Publishable** (`sb_publishable_...`) que você copiou. Nunca use a chave `sb_secret_...` ou `service_role` no aplicativo Android.

## Preparar o projeto Android

Este pacote contém o código Dart e o SQL do banco. Para gerar os arquivos nativos Android, em um computador com Flutter instalado, abra o terminal nesta pasta e execute:

```bash
flutter create --platforms=android .
flutter pub get
```

No Supabase, abra o **SQL Editor** e execute `supabase/schema.sql` (se ainda não tiver executado). O script cria a tabela `methods` e as políticas RLS para cada usuário.

## Executar no celular conectado por USB

```bash
flutter run --dart-define=SUPABASE_URL=https://qteoohevgetmaphuayjx.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_PUBLISHABLE
```

## Gerar APK de instalação

```bash
flutter build apk --release --dart-define=SUPABASE_URL=https://qteoohevgetmaphuayjx.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_PUBLISHABLE
```

Se o build terminar com sucesso, o APK ficará em:

`build/app/outputs/flutter-apk/app-release.apk`

## O que já está incluído

- Login e criação de conta por e-mail/senha.
- Lista de métodos, pesquisa e filtro por marca.
- Cadastro, edição, exclusão e favoritos.
- Campos de marca, modelo, versão Android/iOS e procedimento.
- Isolamento dos registros por usuário usando Row Level Security.

## Observações

- O pacote é código-fonte inicial, não é um APK compilado.
- Este ambiente de conversa não tem Flutter SDK instalado para compilar e assinar o APK diretamente.
- Não compartilhe senhas nem chaves Secret. A chave Publishable é a apropriada para o cliente, junto com as políticas RLS.
- Upload de fotos/documentos para Supabase Storage ainda é uma melhoria da próxima etapa.
