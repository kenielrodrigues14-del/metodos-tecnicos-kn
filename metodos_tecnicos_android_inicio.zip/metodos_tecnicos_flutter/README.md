# Métodos Técnicos — Android

Projeto inicial em Flutter com visual dark e integração preparada para Supabase.

## O que já está incluído
- Tela de login e criação de conta por e-mail/senha.
- Biblioteca de métodos com pesquisa e filtros por marca.
- Cadastro, edição, exclusão e favoritos.
- Isolamento dos registros por usuário usando Row Level Security (RLS).
- Campos para marca, modelo, versão Android/iOS e procedimento.

## Requisitos
- Flutter SDK instalado
- Android Studio (ou VS Code com extensão Flutter)
- Conta/projeto no Supabase

## 1. Preparar o Supabase
1. Crie um projeto em https://supabase.com/
2. Abra **SQL Editor** no painel do projeto.
3. Execute o conteúdo de `supabase/schema.sql`.
4. Em **Project Settings > API**, copie a Project URL e a chave `anon`/publishable.
5. Em **Authentication > URL Configuration / Providers**, mantenha Email habilitado. Para testes, configure a confirmação de e-mail conforme sua preferência.

## 2. Configurar e executar
No terminal, dentro da pasta do projeto:

```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://SEU-PROJETO.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_PUBLICA
```

Nunca coloque a `service_role` key dentro do aplicativo. Use somente a chave pública anon/publishable; a segurança dos dados é aplicada pelas políticas RLS.

## 3. Gerar APK de teste
```bash
flutter build apk --release --dart-define=SUPABASE_URL=https://SEU-PROJETO.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_PUBLICA
```
O APK, se o build terminar com sucesso, fica em `build/app/outputs/flutter-apk/app-release.apk`.

## Próximas melhorias
- Upload de fotos e documentos para Supabase Storage.
- Anexos por método, com regras privadas por usuário.
- Exportação/backup e restauração.
- Campos adicionais e histórico de alterações.

Este pacote é um ponto de partida de código-fonte, não um APK já compilado.
